fn main() {
    // Analysis goes here
}
